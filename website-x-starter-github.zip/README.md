# Website X - Beta Admin Portal

This is the first multi-company admin portal for the Safety Assessment platform.

## What this version does

- Supabase email/password login
- Creates a first company for a new account
- Company-level admin settings
- Company-specific shared pricebook stored in Supabase
- Safety Assessment module preview
- Personalized iframe embed code using the company ID
- Module placeholders for Troubleshooting and Question App
- Company plan/status fields ready for future billing

## GitHub / Netlify structure

Upload the contents of this folder to the root of a new GitHub repo.

Netlify automatically publishes `site/` and bundles `netlify/functions/` using `netlify.toml`.

## Step 1 - Create Supabase

1. Create a new Supabase project.
2. Open SQL Editor.
3. Paste the entire contents of `supabase/schema.sql` and run it.
4. In Supabase Project Settings / API, copy:
   - Project URL
   - anon/public key

## Step 2 - Add Netlify environment variables

In Website X's Netlify project add:

- `SUPABASE_URL` = your Supabase Project URL
- `SUPABASE_ANON_KEY` = your Supabase anon/public key
- `SAFETY_APP_URL` = `https://safetycheck2.netlify.app/`

`SUPABASE_ANON_KEY` is designed to be public when Row Level Security is configured correctly. Never put the Supabase service-role key into browser code.

Redeploy after adding the variables.

## Step 3 - Create first beta account

Open Website X and use Create Beta Account. If Supabase email confirmation is enabled, confirm the email and then sign in.

On first login the portal asks for a company name and creates that company with the signed-in user as its admin.

## Important current limitation

The existing Safety Assessment at `safetycheck2.netlify.app` does not yet read its company pricebook/checklist from Supabase. Website X now creates a company-specific iframe URL with `?company=<company-id>`, but the Safety Assessment needs the next integration update before it will actually consume those Supabase values.

That integration is the next milestone.
