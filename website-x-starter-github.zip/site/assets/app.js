import { createClient } from 'https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2.49.4/+esm';

const state = {
  supabase: null,
  config: null,
  session: null,
  company: null,
  membership: null,
  pricebook: []
};

const $ = (id) => document.getElementById(id);
const money = (n) => Number(n || 0).toLocaleString(undefined,{style:'currency',currency:'USD',maximumFractionDigits:0});

async function boot() {
  try {
    state.config = await fetch('/api/config', { cache: 'no-store' }).then(r => r.json());
    if (!state.config.supabaseUrl || !state.config.supabaseAnonKey) {
      $('boot').innerHTML = `<div class="auth-card"><h1>Website X</h1><div class="notice">Supabase is not connected yet. Add <b>SUPABASE_URL</b> and <b>SUPABASE_ANON_KEY</b> to Netlify environment variables, then redeploy.</div></div>`;
      return;
    }
    state.supabase = createClient(state.config.supabaseUrl, state.config.supabaseAnonKey);
    const { data } = await state.supabase.auth.getSession();
    state.session = data.session;
    state.supabase.auth.onAuthStateChange(async (_event, session) => {
      state.session = session;
      await renderAuthState();
    });
    bindUi();
    await renderAuthState();
  } catch (err) {
    $('boot').innerHTML = `<div class="auth-card"><h1>Website X</h1><div class="notice">Could not start the portal: ${escapeHtml(err.message)}</div></div>`;
  }
}

function bindUi() {
  $('signInBtn').addEventListener('click', signIn);
  $('signUpBtn').addEventListener('click', signUp);
  $('signOutBtn').addEventListener('click', () => state.supabase.auth.signOut());
  document.querySelectorAll('#nav button').forEach(btn => btn.addEventListener('click', () => showSection(btn.dataset.section, btn.textContent)));
  $('saveCompanyBtn').addEventListener('click', saveCompany);
  $('addPricebookBtn').addEventListener('click', () => { state.pricebook.push(blankItem()); renderPricebook(); });
  $('savePricebookBtn').addEventListener('click', savePricebook);
  $('copyEmbedBtn').addEventListener('click', copyEmbed);
}

async function renderAuthState() {
  $('boot').classList.add('hidden');
  if (!state.session) {
    $('app').classList.add('hidden');
    $('auth').classList.remove('hidden');
    return;
  }
  $('auth').classList.add('hidden');
  $('app').classList.remove('hidden');
  await loadCompanyContext();
}

async function signIn() {
  setStatus('authStatus','Signing in…');
  const { error } = await state.supabase.auth.signInWithPassword({ email: $('authEmail').value.trim(), password: $('authPassword').value });
  if (error) setStatus('authStatus', error.message, true); else setStatus('authStatus','Signed in.');
}

async function signUp() {
  setStatus('authStatus','Creating account…');
  const email = $('authEmail').value.trim();
  const password = $('authPassword').value;
  const { data, error } = await state.supabase.auth.signUp({ email, password });
  if (error) return setStatus('authStatus', error.message, true);
  if (!data.session) {
    setStatus('authStatus','Account created. Check your email if confirmation is enabled, then sign in.');
    return;
  }
  setStatus('authStatus','Account created.');
}

async function loadCompanyContext() {
  const userId = state.session.user.id;
  const { data: membership, error } = await state.supabase
    .from('company_users')
    .select('company_id, role, companies(*)')
    .eq('user_id', userId)
    .maybeSingle();

  if (error) return showSetup(`Could not load company membership: ${error.message}`);
  if (!membership) {
    const name = prompt('No company is connected to this account yet. Enter your company name to create one:');
    if (!name) return showSetup('Create a company to continue. Sign out and back in when ready.');
    const { data, error: rpcError } = await state.supabase.rpc('create_company_for_current_user', { p_name: name });
    if (rpcError) return showSetup(`Could not create company: ${rpcError.message}`);
    await loadCompanyContext();
    return;
  }

  state.membership = membership;
  state.company = membership.companies;
  $('setupNotice').classList.add('hidden');
  $('sidebarCompany').textContent = state.company.name;
  $('metricCompany').textContent = state.company.name;
  $('metricPlan').textContent = state.company.plan || 'Beta';
  $('roleBadge').textContent = membership.role || 'admin';
  fillCompanyForm();
  await loadPricebook();
  updateEmbed();
}

function showSetup(message) {
  $('setupNotice').textContent = message;
  $('setupNotice').classList.remove('hidden');
}

function fillCompanyForm() {
  $('companyName').value = state.company.name || '';
  $('officeEmail').value = state.company.office_email || '';
  $('replyToEmail').value = state.company.reply_to_email || '';
  $('companyPhone').value = state.company.phone || '';
}

async function saveCompany() {
  if (!state.company) return;
  setStatus('companyStatus','Saving…');
  const payload = {
    name: $('companyName').value.trim(),
    office_email: $('officeEmail').value.trim() || null,
    reply_to_email: $('replyToEmail').value.trim() || null,
    phone: $('companyPhone').value.trim() || null
  };
  const { data, error } = await state.supabase.from('companies').update(payload).eq('id', state.company.id).select().single();
  if (error) return setStatus('companyStatus',error.message,true);
  state.company = data;
  $('sidebarCompany').textContent = data.name;
  $('metricCompany').textContent = data.name;
  setStatus('companyStatus','Saved.');
}

async function loadPricebook() {
  const { data, error } = await state.supabase.from('pricebook_items').select('*').eq('company_id', state.company.id).order('sort_order').order('name');
  if (error) {
    setStatus('pricebookStatus', error.message, true);
    state.pricebook = [];
  } else {
    state.pricebook = data || [];
  }
  renderPricebook();
}

function blankItem() {
  return { id: crypto.randomUUID(), isNew: true, name: '', min_price: 0, max_price: 0, labor_min: 0, labor_max: 0, active: true };
}

function renderPricebook() {
  const body = $('pricebookBody');
  body.innerHTML = '';
  state.pricebook.forEach((item, index) => {
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td><input class="input" data-field="name" data-index="${index}" value="${escapeAttr(item.name || '')}"></td>
      <td><input class="input" data-field="min_price" data-index="${index}" type="number" min="0" step="1" value="${Number(item.min_price || 0)}"></td>
      <td><input class="input" data-field="max_price" data-index="${index}" type="number" min="0" step="1" value="${Number(item.max_price || 0)}"></td>
      <td><input class="input" data-field="labor_min" data-index="${index}" type="number" min="0" step="1" value="${Number(item.labor_min || 0)}"></td>
      <td><input class="input" data-field="labor_max" data-index="${index}" type="number" min="0" step="1" value="${Number(item.labor_max || 0)}"></td>
      <td><button class="btn danger" data-remove="${index}" type="button">Remove</button></td>`;
    body.appendChild(tr);
  });
  body.querySelectorAll('input').forEach(input => input.addEventListener('input', e => {
    const i = Number(e.target.dataset.index);
    const field = e.target.dataset.field;
    state.pricebook[i][field] = e.target.type === 'number' ? Number(e.target.value) : e.target.value;
  }));
  body.querySelectorAll('[data-remove]').forEach(btn => btn.addEventListener('click', () => {
    state.pricebook.splice(Number(btn.dataset.remove),1);
    renderPricebook();
  }));
}

async function savePricebook() {
  if (!state.company) return;
  setStatus('pricebookStatus','Saving…');
  const existing = await state.supabase.from('pricebook_items').select('id').eq('company_id', state.company.id);
  if (existing.error) return setStatus('pricebookStatus',existing.error.message,true);
  const currentIds = new Set(state.pricebook.filter(x => !x.isNew).map(x => x.id));
  const deleteIds = (existing.data || []).map(x=>x.id).filter(id => !currentIds.has(id));
  if (deleteIds.length) {
    const del = await state.supabase.from('pricebook_items').delete().in('id', deleteIds);
    if (del.error) return setStatus('pricebookStatus',del.error.message,true);
  }
  const rows = state.pricebook.filter(x => x.name.trim()).map((x,i) => ({
    ...(x.isNew ? {} : { id: x.id }),
    company_id: state.company.id,
    name: x.name.trim(),
    min_price: Number(x.min_price || 0),
    max_price: Number(x.max_price || 0),
    labor_min: Number(x.labor_min || 0),
    labor_max: Number(x.labor_max || 0),
    sort_order: i,
    active: true
  }));
  const { error } = await state.supabase.from('pricebook_items').upsert(rows, { onConflict: 'id' });
  if (error) return setStatus('pricebookStatus',error.message,true);
  await loadPricebook();
  setStatus('pricebookStatus','Saved. These values are now shared for this company.');
}

function updateEmbed() {
  if (!state.company || !state.config) return;
  const base = state.config.safetyAppUrl || 'https://safetycheck2.netlify.app/';
  const url = new URL(base);
  url.searchParams.set('company', state.company.id);
  const code = `<iframe\n  src="${url.toString()}"\n  title="Electrical Safety Assessment"\n  style="width:100%;height:1800px;border:0;display:block"\n  loading="lazy">\n</iframe>`;
  $('embedCode').textContent = code;
  $('safetyPreview').src = url.toString();
}

async function copyEmbed() {
  try {
    await navigator.clipboard.writeText($('embedCode').textContent);
    setStatus('embedStatus','Copied.');
  } catch {
    setStatus('embedStatus','Copy failed. Select the code manually.', true);
  }
}

function showSection(id, title) {
  document.querySelectorAll('.section').forEach(x => x.classList.toggle('active', x.id === id));
  document.querySelectorAll('#nav button').forEach(x => x.classList.toggle('active', x.dataset.section === id));
  $('pageTitle').textContent = title;
  const subtitles = {
    dashboard:'Manage your company and app modules.',
    company:'Company identity and communication defaults.',
    safety:'Configure and preview the Safety Assessment module.',
    pricebook:'Company-controlled planning ranges.',
    apps:'Enable modules and future add-ons.',
    embed:'Install the company-specific app on any website.'
  };
  $('pageSubtitle').textContent = subtitles[id] || '';
}

function setStatus(id, text, error=false) {
  const el = $(id); el.textContent = text; el.className = 'status ' + (error ? 'error' : 'success');
}
function escapeAttr(s){ return String(s).replace(/[&<>"']/g,c=>({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;' }[c])); }
function escapeHtml(s){ return escapeAttr(s); }

boot();
