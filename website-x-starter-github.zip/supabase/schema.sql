-- Website X beta schema
-- Run this entire file in Supabase SQL Editor once.

create extension if not exists pgcrypto;

create table if not exists public.companies (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  office_email text,
  reply_to_email text,
  phone text,
  plan text not null default 'Beta',
  subscription_status text not null default 'active',
  safety_enabled boolean not null default true,
  troubleshooting_enabled boolean not null default false,
  question_app_enabled boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.company_users (
  company_id uuid not null references public.companies(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  role text not null default 'admin' check (role in ('admin','technician')),
  created_at timestamptz not null default now(),
  primary key (company_id, user_id)
);

create table if not exists public.pricebook_items (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  name text not null,
  min_price numeric(12,2) not null default 0,
  max_price numeric(12,2) not null default 0,
  labor_min integer not null default 0,
  labor_max integer not null default 0,
  active boolean not null default true,
  sort_order integer not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.checklist_items (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  section text not null default 'General',
  label text not null,
  severity text not null default 'moderate',
  flag_deduction numeric(6,2) not null default 0,
  fail_deduction numeric(6,2) not null default 0,
  flag_score_cap numeric(6,2),
  fail_score_cap numeric(6,2),
  pricebook_item_id uuid references public.pricebook_items(id) on delete set null,
  active boolean not null default true,
  sort_order integer not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.profile_fields (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  label text not null,
  field_type text not null default 'text' check (field_type in ('text','number','multiple_choice')),
  required boolean not null default false,
  affects_score boolean not null default false,
  sort_order integer not null default 0,
  active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.profile_choices (
  id uuid primary key default gen_random_uuid(),
  profile_field_id uuid not null references public.profile_fields(id) on delete cascade,
  label text not null,
  severity text,
  deduction numeric(6,2) not null default 0,
  score_cap numeric(6,2),
  sort_order integer not null default 0
);

create table if not exists public.assessments (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  technician_user_id uuid references auth.users(id) on delete set null,
  customer_name text,
  customer_email text,
  customer_phone text,
  customer_address text,
  raw_score numeric(6,2),
  final_score numeric(6,2),
  status text not null default 'draft',
  created_at timestamptz not null default now(),
  completed_at timestamptz
);

-- Helper: returns true when the signed-in user belongs to the company.
create or replace function public.user_belongs_to_company(p_company_id uuid)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1 from public.company_users
    where company_id = p_company_id and user_id = auth.uid()
  );
$$;

-- Helper: returns true when the signed-in user is an admin for the company.
create or replace function public.user_is_company_admin(p_company_id uuid)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1 from public.company_users
    where company_id = p_company_id and user_id = auth.uid() and role = 'admin'
  );
$$;

-- First-company bootstrap for a newly authenticated user.
create or replace function public.create_company_for_current_user(p_name text)
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  v_company_id uuid;
begin
  if auth.uid() is null then
    raise exception 'Not authenticated';
  end if;

  if exists (select 1 from public.company_users where user_id = auth.uid()) then
    raise exception 'User already belongs to a company';
  end if;

  insert into public.companies(name) values (trim(p_name)) returning id into v_company_id;
  insert into public.company_users(company_id,user_id,role) values (v_company_id,auth.uid(),'admin');
  return v_company_id;
end;
$$;

grant execute on function public.create_company_for_current_user(text) to authenticated;

grant execute on function public.user_belongs_to_company(uuid) to authenticated;
grant execute on function public.user_is_company_admin(uuid) to authenticated;

alter table public.companies enable row level security;
alter table public.company_users enable row level security;
alter table public.pricebook_items enable row level security;
alter table public.checklist_items enable row level security;
alter table public.profile_fields enable row level security;
alter table public.profile_choices enable row level security;
alter table public.assessments enable row level security;

-- Companies
create policy "members read company" on public.companies for select to authenticated
using (public.user_belongs_to_company(id));
create policy "admins update company" on public.companies for update to authenticated
using (public.user_is_company_admin(id)) with check (public.user_is_company_admin(id));

-- Company users
create policy "members read memberships" on public.company_users for select to authenticated
using (public.user_belongs_to_company(company_id));
create policy "admins manage memberships" on public.company_users for all to authenticated
using (public.user_is_company_admin(company_id)) with check (public.user_is_company_admin(company_id));

-- Pricebook
create policy "members read pricebook" on public.pricebook_items for select to authenticated
using (public.user_belongs_to_company(company_id));
create policy "admins manage pricebook" on public.pricebook_items for all to authenticated
using (public.user_is_company_admin(company_id)) with check (public.user_is_company_admin(company_id));

-- Checklist
create policy "members read checklist" on public.checklist_items for select to authenticated
using (public.user_belongs_to_company(company_id));
create policy "admins manage checklist" on public.checklist_items for all to authenticated
using (public.user_is_company_admin(company_id)) with check (public.user_is_company_admin(company_id));

-- Profile fields
create policy "members read profile fields" on public.profile_fields for select to authenticated
using (public.user_belongs_to_company(company_id));
create policy "admins manage profile fields" on public.profile_fields for all to authenticated
using (public.user_is_company_admin(company_id)) with check (public.user_is_company_admin(company_id));

-- Profile choices inherit access through parent field.
create policy "members read profile choices" on public.profile_choices for select to authenticated
using (exists(select 1 from public.profile_fields f where f.id = profile_field_id and public.user_belongs_to_company(f.company_id)));
create policy "admins manage profile choices" on public.profile_choices for all to authenticated
using (exists(select 1 from public.profile_fields f where f.id = profile_field_id and public.user_is_company_admin(f.company_id)))
with check (exists(select 1 from public.profile_fields f where f.id = profile_field_id and public.user_is_company_admin(f.company_id)));

-- Assessments: members can read/create/update their company's records during beta.
create policy "members read assessments" on public.assessments for select to authenticated
using (public.user_belongs_to_company(company_id));
create policy "members create assessments" on public.assessments for insert to authenticated
with check (public.user_belongs_to_company(company_id));
create policy "members update assessments" on public.assessments for update to authenticated
using (public.user_belongs_to_company(company_id)) with check (public.user_belongs_to_company(company_id));

-- Helpful starter data is added after the first company is created from the portal.
